i=1;
/*int w;
i=0;
if(w==0)
{
  w++;
}


a=7;*/
