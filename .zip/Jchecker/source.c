a=-(a-b)-c-d*e+7-10;
/*int c,b,a,d,e;

while(c<1){b=c+1-5*6+7;c=c+1;}

if (c<d&&c>d-5||(a>=0)){ERROR;} else {a=b;c=d;e=e+1;}

return c-d;*/
//ay = bj + 1;
b = c -2 +3 *b ;
//下面在原基础上不断添加实验新的语法（在jchecker2上做）
//i=1;
/*int w;
i=0;
if(w==0)
{
  w++;
}


a=7;*/
