package tokens;
import java.lang.*;
import java.util.*;
public enum ConType {T,F,equal,notequal,larger,smaller,equallarger,equalsmaller}