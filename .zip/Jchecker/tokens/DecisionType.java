package tokens;
import java.lang.*;
import java.util.*;
public enum DecisionType{ifsentence,whilesentence}