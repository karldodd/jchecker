package tokens;
import java.lang.*;
import java.util.*;
public class ErrorSentence extends Sentence{
	String errorString;
	public ErrorSentence(){}
	public String toString(){return "ERROR;";}
}