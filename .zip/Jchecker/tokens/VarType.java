package tokens;
import java.lang.*;
import java.util.*;
public enum VarType{integer}